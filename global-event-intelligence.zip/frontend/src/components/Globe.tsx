import { useEffect, useRef } from "react";
import ThreeGlobe from "three-globe";
import * as THREE from "three";
import { EventItem } from "../types";

export default function Globe({ events, onSelect }: { events: EventItem[]; onSelect: (e: EventItem) => void }) {
  const mount = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mount.current) return;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000);
    camera.position.z = 280;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(mount.current.clientWidth, mount.current.clientHeight);
    mount.current.innerHTML = "";
    mount.current.appendChild(renderer.domElement);

    const globe = new ThreeGlobe()
      .globeImageUrl("//unpkg.com/three-globe/example/img/earth-blue-marble.jpg")
      .bumpImageUrl("//unpkg.com/three-globe/example/img/earth-topology.png")
      .pointsData(events.filter(e => e.latitude !== null && e.longitude !== null))
      .pointLat("latitude")
      .pointLng("longitude")
      .pointAltitude(e => 0.02 + (e as EventItem).importance * 0.012)
      .pointRadius(e => 0.7 + (e as EventItem).importance * 0.10)
      .pointColor(() => "#ff4d6d")
      .onPointClick((point: object) => onSelect(point as EventItem));

    scene.add(globe);
    scene.add(new THREE.AmbientLight(0xffffff, 2));
    scene.add(new THREE.DirectionalLight(0xffffff, 1));

    let animation = 0;
    const resize = () => {
      if (!mount.current) return;
      const w = mount.current.clientWidth;
      const h = mount.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", resize);

    const loop = () => {
      animation = requestAnimationFrame(loop);
      globe.rotation.y += 0.0007;
      renderer.render(scene, camera);
    };
    loop();

    return () => {
      cancelAnimationFrame(animation);
      window.removeEventListener("resize", resize);
      renderer.dispose();
      mount.current?.replaceChildren();
    };
  }, [events, onSelect]);

  return <div className="globe" ref={mount} />;
}
